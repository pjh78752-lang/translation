import ctypes as C
from pathlib import Path
import numpy as np
from PIL import Image

CORE = '/workspace/rom-tools/Genesis-Plus-GX/genesis_plus_gx_libretro.so'
class Game(C.Structure):
    _fields_ = [('path', C.c_char_p), ('data', C.c_void_p), ('size', C.c_size_t), ('meta', C.c_char_p)]
class Emulator:
    def __init__(self, path):
        self.lib=C.CDLL(CORE); self.buttons=set(); self.frame=None; self.callbacks=[]
        self.directory=C.c_char_p(b'/workspace/translation/output')
        def env(cmd, data):
            if cmd in (9,31):
                C.cast(data,C.POINTER(C.c_char_p))[0]=self.directory.value; return True
            if cmd==10:
                self.pixel=C.cast(data,C.POINTER(C.c_int))[0]; return True
            if cmd==3: C.cast(data,C.POINTER(C.c_bool))[0]=False; return True
            if cmd==15: return False
            if cmd==17: C.cast(data,C.POINTER(C.c_bool))[0]=False; return True
            return False
        def video(data,w,h,pitch):
            if not data:return
            raw=C.string_at(data,pitch*h)
            if getattr(self,'pixel',2)==2:
                a=np.frombuffer(raw,dtype=np.uint16).reshape(h,pitch//2)[:,:w]
                self.frame=np.stack([((a>>11)&31)*255//31,((a>>5)&63)*255//63,(a&31)*255//31],axis=-1).astype('uint8')
            else:
                a=np.frombuffer(raw,dtype=np.uint8).reshape(h,pitch)[:,:w*4].reshape(h,w,4)
                self.frame=a[:,:,[2,1,0]].copy()
        def register(name,typ,fun):
            cb=typ(fun);self.callbacks.append(cb);getattr(self.lib,name)(cb)
        register('retro_set_environment',C.CFUNCTYPE(C.c_bool,C.c_uint,C.c_void_p),env)
        register('retro_set_video_refresh',C.CFUNCTYPE(None,C.c_void_p,C.c_uint,C.c_uint,C.c_size_t),video)
        register('retro_set_audio_sample',C.CFUNCTYPE(None,C.c_int16,C.c_int16),lambda l,r:None)
        register('retro_set_audio_sample_batch',C.CFUNCTYPE(C.c_size_t,C.c_void_p,C.c_size_t),lambda p,n:n)
        register('retro_set_input_poll',C.CFUNCTYPE(None),lambda:None)
        register('retro_set_input_state',C.CFUNCTYPE(C.c_int16,C.c_uint,C.c_uint,C.c_uint,C.c_uint),lambda p,d,i,k:int(p==0 and k in self.buttons))
        self.lib.retro_init()
        self.rom=C.create_string_buffer(Path(path).read_bytes())
        game=Game(str(path).encode(),C.cast(self.rom,C.c_void_p),len(self.rom)-1,None)
        self.lib.retro_load_game.argtypes=[C.POINTER(Game)];self.lib.retro_load_game.restype=C.c_bool
        assert self.lib.retro_load_game(C.byref(game))
        self.lib.retro_get_memory_data.restype=C.c_void_p
        self.ram=(C.c_uint8*65536).from_address(self.lib.retro_get_memory_data(2))
    def run(self,n,buttons=()):
        self.buttons=set(buttons)
        for _ in range(n): self.lib.retro_run()
    def shot(self,name): Image.fromarray(self.frame).save(name)
    def read16(self,offset): return (self.ram[offset^1]<<8)|self.ram[(offset+1)^1]
    def write16(self,offset,v): self.ram[offset^1]=v>>8;self.ram[(offset+1)^1]=v&255

if __name__=='__main__':
    import sys
    em=Emulator(sys.argv[1]);out=Path('/workspace/translation/output')
    for n in range(1,11):
        em.run(120);em.shot(out/f'original-{n:02}.png')
