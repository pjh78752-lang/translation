    .cpu 68000
    .text
    .globl _start
_start:
    cmpi.w #0xfd,%d7
    beq.w korean
    addq.l #1,0x0e(%a0)
    jmp 0x36e4a
korean:
    bsr.w drawglyph
    jmp 0x36e8a
drawglyph:
    movem.l %d0-%d6/%a0-%a3,-(%sp)
    movea.l 0x0e(%a0),%a1
    addq.l #1,%a1
    moveq #0,%d0
    move.b (%a1)+,%d0
    lsl.w #8,%d0
    move.b (%a1)+,%d0
    move.l %a1,0x0e(%a0)
    btst #15,%d0
    bne.w menufont
    move.l %d0,%d2
    lsl.l #7,%d2
    lea 0x110000,%a2
    adda.l %d2,%a2
    | Five rows of fifteen 16px cells, wholly below portrait tiles.
    moveq #0,%d0
    move.w 0x14(%a0),%d0
    lsr.w #1,%d0
    divu.w #4,%d0
    swap %d0
    mulu.w #20,%d0
    move.w 0x12(%a0),%d1
    lsr.w #1,%d1
    add.w %d1,%d0
    lsl.w #2,%d0
    addi.w #0x380,%d0
    bra.w slotready
menufont:
    andi.l #0x7fff,%d0
    move.l %d0,%d2
    lsl.l #7,%d2
    lea 0x140000,%a2
    adda.l %d2,%a2
    andi.w #63,%d0
    lsl.w #2,%d0
    addi.w #0x680,%d0
    cmpi.w #0x700,%d0
    bcs.w slotready
    addi.w #0x80,%d0
slotready:
    move.w %d0,%d3
    lsl.l #5,%d0
    move.l %d0,%d1
    andi.l #0x3fff,%d0
    ori.w #0x4000,%d0
    swap %d0
    lsr.l #8,%d1
    lsr.l #6,%d1
    or.l %d1,%d0
    lea 0xc00000,%a3
    move.w %sr,-(%sp)
    ori.w #0x0700,%sr
    move.w #0x8f02,4(%a3)
    move.l %d0,4(%a3)
    moveq #31,%d1
upload:
    move.l (%a2)+,(%a3)
    dbra %d1,upload
    move.w (%sp)+,%sr
    move.w 0x0c(%a0),%d2
    or.w %d3,%d2
    move.w 0x12(%a0),%d0
    move.w 0x14(%a0),%d1
    bsr.w cell
    addq.w #1,%d0
    addq.w #1,%d2
    bsr.w cell
    subq.w #1,%d0
    addq.w #1,%d1
    addq.w #1,%d2
    bsr.w cell
    addq.w #1,%d0
    addq.w #1,%d2
    bsr.w cell
    addq.w #2,0x12(%a0)
    movem.l (%sp)+,%d0-%d6/%a0-%a3
    rts
cell:
    movem.l %d0-%d3/%a0,-(%sp)
    move.w %d0,%d5
    move.w %d1,%d6
    move.w %d2,%d7
    jsr 0x1498
    movem.l (%sp)+,%d0-%d3/%a0
    rts

    .globl menuhook
menuhook:
    cmpi.w #0xfd,%d7
    beq.w menukorean
    movem.l %d4-%d6/%a0,-(%sp)
    tst.w %d4
    jmp 0x1488
menukorean:
    movem.l %d0-%d4/%a1-%a3,-(%sp)
    movea.l %a0,%a3
    movea.l %a0,%a1
    subq.l #1,%a1
    tst.w %d4
    beq.w menunormal
    lea space(%pc),%a1
menunormal:
    lea -0x20(%sp),%sp
    movea.l %sp,%a0
    move.w %d5,0x12(%a0)
    move.w %d6,0x14(%a0)
    clr.w 0x0c(%a0)
    move.l %a1,0x0e(%a0)
    bsr.w drawglyph
    lea 0x20(%sp),%sp
    movea.l %a3,%a0
    addq.l #2,%a0
    addq.w #2,%d5
    movem.l (%sp)+,%d0-%d4/%a1-%a3
    jmp 0x1472
space:
    .byte 0xfd,0x80,0
    .even
    .globl titlehook
titlehook:
    lea 0x138000,%a0
    moveq #0,%d6
    jmp 0x37cd2
    .globl levelhook
levelhook:
    lea 0x132000,%a0
    add.w %d0,%d0
    adda.w (%a0,%d0.w),%a0
    moveq #0,%d6
    jmp 0x1468
    .globl moviehook
moviehook:
    lea 0x133000,%a0
    add.w %d0,%d0
    adda.w (%a0,%d0.w),%a0
    moveq #0,%d6
    jmp 0x1468
    .globl errorhook
errorhook:
    lea 0x139000,%a0
    moveq #0,%d6
    jmp 0x3e3e8
    .globl clearerrorhook
clearerrorhook:
    lea 0x139100,%a0
    moveq #0,%d6
    jmp 0x3e40c
