"""Render every translated dialogue from an emulated intro snapshot."""
import ctypes as C, json, sys
from pathlib import Path
import numpy as np
from emulate import Emulator
ROOT=Path(__file__).resolve().parents[1]
rom=ROOT/'output/Animaniacs-Korean.md'
em=Emulator(rom); em.run(1280)
lib=em.lib
lib.retro_serialize_size.restype=C.c_size_t
size=lib.retro_serialize_size();state=C.create_string_buffer(size)
lib.retro_serialize.argtypes=[C.c_void_p,C.c_size_t];lib.retro_serialize.restype=C.c_bool
lib.retro_unserialize.argtypes=[C.c_void_p,C.c_size_t];lib.retro_unserialize.restype=C.c_bool
assert lib.retro_serialize(state,size)
b=rom.read_bytes();results=[]
for n in range(85):
    assert lib.retro_unserialize(state,size)
    for off,v in [(0,n),(2,1),(4,0),(6,0),(8,1),(10,0),(24,0)]:em.write16(0x2802+off,v)
    start=0x100000+int.from_bytes(b[0x100000+n*2:0x100002+n*2],'big')+1
    ptr=start;expected=set()
    while b[ptr]!=255:
        if b[ptr]==253:ptr+=3;expected.add(ptr)
        else:assert b[ptr]==254;ptr+=1
    end=ptr;seen=set()
    for frames in range(4000):
        em.run(1)
        pos=em.read16(0x2810)*65536+em.read16(0x2812)
        seen.add(pos)
        if pos==end-1 and n in [0,2,33,47,64,71,78,84]:
            em.shot(ROOT/f'output/dialogue-{n:02}.png')
        if pos==end:break
    else:raise AssertionError(f'Dialogue {n} failed to reach end; pointer={pos:x}')
    missing=expected-seen
    assert not missing,(n,'unrendered characters',missing)
    for settle in range(300):
        if em.read16(0x280c)==4 and em.read16(0x281a)==1:break
        em.run(1)
    else:raise AssertionError(f'Dialogue {n} did not complete its scrolling/finish state')
    results.append({'dialogue':n,'glyphs_rendered':len(expected),'frames':frames+1,'passed':True})
(ROOT/'output/validation.json').write_text(json.dumps(results,indent=2))
print(f'PASS: {len(results)} dialogue entries; {sum(x["glyphs_rendered"] for x in results)} glyph draws observed.')
