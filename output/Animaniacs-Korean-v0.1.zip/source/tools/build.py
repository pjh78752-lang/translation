"""Build a ROM and IPS from the user's own unmodified Animaniacs (USA) dump."""
import hashlib, json, os, struct, subprocess, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT=Path(__file__).resolve().parents[1]
EXPECTED='31fbf9d442d578c43788a024336639648d5c7dab4502636e127190c991ff3604'
MENUS=[[(16,19,'시작')],[(16,21,'암호')],[(16,23,'설정')],
 [(14,14,'애니매니악스')],[(14,16,'코나미 1994')],[(12,8,'게임')],[(12,8,'시연')],[(2,2,'제목')],
 [(16,4,'설정'),(9,7,'난이도'),(22,9,'인원'),(9,13,'조작'),(22,13,'A'),(22,15,'B'),(22,17,'C'),(9,21,'음향'),(18,24,'나가기')],
 [(23,21,'입체음향')],[(23,21,'단일음향')],[(23,7,'쉬움    ')],[(23,7,'보통    ')],[(23,7,'어려움  ')],[(23,7,'매우어려움')]]
LEVELS=['정글에서 생긴 일','우주 트럭 운송','알라모를 기억하라','비명을 지를까 말까','오스카라는 이름의 남자']
MOVIES=['더크 러기드의 모험 2','우주 전쟁','낮게 흔들고 높게 매달아라','피의 가면 32편','']
def build(source):
    original=Path(source).read_bytes()
    if hashlib.sha256(original).hexdigest()!=EXPECTED:
        raise SystemExit('Wrong source ROM: SHA-256 does not match supported USA revision.')
    texts=json.loads((ROOT/'dialogue-ko.json').read_text())
    assert len(texts)==85
    glyphs=sorted(set(''.join(texts))-{'\n'})
    ids={c:i for i,c in enumerate(glyphs)}
    menuchars=[' ']+sorted((set(''.join(t for menu in MENUS for x,y,t in menu))|set('동작점프교체암호가 틀렸습니다.'))-{' '})
    menuids={c:i for i,c in enumerate(menuchars)}
    assert len(menuchars)<=64
    allmenuchars=menuchars+[' ']*(64-len(menuchars))
    stageids=[]
    for level,movie in zip(LEVELS,MOVIES):
        chars=sorted(set(level+movie));assert len(chars)<=64
        stageids.append({c:len(allmenuchars)+i for i,c in enumerate(chars)})
        allmenuchars.extend(chars+[' ']*(64-len(chars)))
    font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc',14,index=1)
    fontdata=bytearray()
    for c in glyphs+allmenuchars:
        im=Image.new('L',(16,16)); d=ImageDraw.Draw(im)
        if c!=' ':
            box=d.textbbox((0,0),c,font=font,anchor='lt')
            d.text(((16-(box[2]-box[0]))//2,1),c,font=font,fill=255,anchor='lt')
        im=im.point(lambda p:255 if p>=100 else 0)
        outline=im.filter(ImageFilter.MaxFilter(3))
        for tx,ty in [(0,0),(8,0),(0,8),(8,8)]:
            for y in range(ty,ty+8):
                for x in range(tx,tx+8,2):
                    def pix(px):return 12 if im.getpixel((px,y)) else 11 if outline.getpixel((px,y)) else 0
                    fontdata.append(pix(x)*16+pix(x+1))
    rom=bytearray(original)
    rom.extend(b'\xff'*(0x200000-len(rom)))
    table=0x100000
    data=bytearray(170)
    for n,text in enumerate(texts):
        # Preserve speaker and all sequence indices from the original game.
        old=0x40d78+int.from_bytes(original[0x40d78+n*2:0x40d7a+n*2],'big')
        struct.pack_into('>H',data,n*2,len(data))
        data.append(original[old])
        lines=[]
        for line in text.split('\n'):
            # At most 15 full-width characters per row; prefer word boundaries.
            while len(line)>15:
                cut=line.rfind(' ',0,16)
                if cut<=0:cut=15
                lines.append(line[:cut]);line=line[cut:].lstrip()
            lines.append(line)
        for line in lines:
            assert len(line)<=15
            for c in line:data.extend(b'\xfd'+struct.pack('>H',ids[c]))
            data.append(254)
        data.append(255)
    assert len(data)<0x8000
    rom[table:table+len(data)]=data
    rom[0x110000:0x110000+len(fontdata)]=fontdata
    rom[0x140000:0x140000+len(allmenuchars)*128]=fontdata[len(glyphs)*128:]
    def menuencode(rows,charids=None):
        charids=menuids if charids is None else charids
        result=bytearray()
        for n,(x,y,text) in enumerate(rows):
            if n:result.append(254)
            result.extend(bytes([x,y]))
            for c in text:result.extend(b'\xfd'+struct.pack('>H',0x8000|charids[c]))
        result.append(255)
        return result
    menudata=bytearray(30)
    for n,rows in enumerate(MENUS):
        struct.pack_into('>H',menudata,n*2,len(menudata));menudata.extend(menuencode(rows))
    rom[0x130000:0x130000+len(menudata)]=menudata
    rom[0x145c:0x1460]=struct.pack('>I',0x130000)
    titledata=menuencode([(16,23,' 시작'),(16,25,' 암호'),(16,27,' 설정')])
    rom[0x138000:0x138000+len(titledata)]=titledata
    for base,names,y in [(0x132000,LEVELS,20),(0x133000,MOVIES,23)]:
        stagedata=bytearray(10)
        for n,name in enumerate(names):
            struct.pack_into('>H',stagedata,n*2,len(stagedata))
            stagedata.extend(menuencode([(20-len(name),y,name)],stageids[n]))
        rom[base:base+len(stagedata)]=stagedata
    warning='암호가 틀렸습니다.'
    for base,text in [(0x139000,warning),(0x139100,' '*len(warning))]:
        encoded=menuencode([(20-len(warning),1,text)])
        rom[base:base+len(encoded)]=encoded
    for address,text in [(0x15dc,'동작'),(0x15e4,'점프'),(0x15ec,'교체')]:
        encoded=b''.join(b'\xfd'+struct.pack('>H',0x8000|menuids[c]) for c in text)
        assert len(encoded)==6
        rom[address:address+6]=encoded
    rom[0x36d4c:0x36d50]=struct.pack('>I',table)
    rom[0x36e46:0x36e4c]=b'\x4e\xf9'+struct.pack('>I',0x108000)
    # Align full 16px cells with the text viewport after vertical scrolling.
    assert original[0x36dc2:0x36dc4]==b'\x00\x12'
    assert original[0x36e24:0x36e26]==b'\x00\x16'
    rom[0x36dc2:0x36dc4]=b'\x00\x13'
    rom[0x36e24:0x36e26]=b'\x00\x17'
    toolbase=Path('/workspace/rom-tools/m68k-old/usr')
    env=os.environ.copy();env['LD_LIBRARY_PATH']=str(toolbase/'lib/x86_64-linux-gnu')
    def run(tool,*args): subprocess.run([str(toolbase/'bin'/('m68k-linux-gnu-'+tool)),*map(str,args)],check=True,env=env)
    out=ROOT/'output';out.mkdir(exist_ok=True)
    run('as','-m68000','-o',out/'hangul.o',ROOT/'tools/hangul.s')
    run('ld','-Ttext=0x108000','-o',out/'hangul.elf',out/'hangul.o')
    run('objcopy','-O','binary',out/'hangul.elf',out/'hangul.bin')
    code=(out/'hangul.bin').read_bytes();rom[0x108000:0x108000+len(code)]=code
    symbols=subprocess.check_output([str(toolbase/'bin/m68k-linux-gnu-nm'),str(out/'hangul.elf')],env=env,text=True)
    addresses={line.split()[2]:int(line.split()[0],16) for line in symbols.splitlines() if len(line.split())==3}
    rom[0x1482:0x1488]=b'\x4e\xf9'+struct.pack('>I',addresses['menuhook'])
    rom[0x37cca:0x37cd2]=b'\x4e\xf9'+struct.pack('>I',addresses['titlehook'])+b'\x4e\x71'
    for address,symbol in [(0x36f54,'levelhook'),(0x36f6c,'moviehook')]:
        rom[address:address+6]=b'\x4e\xf9'+struct.pack('>I',addresses[symbol])
    for address,symbol in [(0x3e3e0,'errorhook'),(0x3e404,'clearerrorhook')]:
        rom[address:address+8]=b'\x4e\xf9'+struct.pack('>I',addresses[symbol])+b'\x4e\x71'
    struct.pack_into('>I',rom,0x1a4,len(rom)-1)
    checksum=sum(struct.unpack('>'+str((len(rom)-0x200)//2)+'H',rom[0x200:]))&65535
    struct.pack_into('>H',rom,0x18e,checksum)
    target=out/'Animaniacs-Korean.md';target.write_bytes(rom)
    # IPS supports ROM expansion; include every changed and appended byte.
    ips=bytearray(b'PATCH');i=0
    while i<len(rom):
        if i<len(original) and rom[i]==original[i]:i+=1;continue
        start=i;i+=1
        while i<len(rom) and i-start<65535 and (i>=len(original) or rom[i]!=original[i]):i+=1
        ips.extend(start.to_bytes(3,'big')+(i-start).to_bytes(2,'big')+rom[start:i])
    ips.extend(b'EOF');(out/'Animaniacs-Korean.ips').write_bytes(ips)
    (out/'build-info.json').write_text(json.dumps({'source_sha256':EXPECTED,'patched_sha256':hashlib.sha256(rom).hexdigest(),'dialogues':len(texts),'glyphs':len(glyphs),'checksum':hex(checksum)},indent=2))
    print(target, 'glyphs',len(glyphs),'dialogues',len(texts),'checksum',hex(checksum))
if __name__=='__main__':build(sys.argv[1])
