"""Usage: python apply_patch.py source.md [output.md]. Standard library only."""
from pathlib import Path
import hashlib, sys

EXPECTED='31fbf9d442d578c43788a024336639648d5c7dab4502636e127190c991ff3604'
def apply(source,patch):
    if hashlib.sha256(source).hexdigest()!=EXPECTED:
        raise ValueError('지원하지 않는 원본입니다. 안내서의 SHA-256을 확인하세요.')
    if patch[:5]!=b'PATCH':raise ValueError('잘못된 IPS 파일입니다.')
    data=bytearray(source);p=5
    while patch[p:p+3]!=b'EOF':
        offset=int.from_bytes(patch[p:p+3],'big');size=int.from_bytes(patch[p+3:p+5],'big');p+=5
        if size:chunk=patch[p:p+size];p+=size
        else:
            size=int.from_bytes(patch[p:p+2],'big');chunk=patch[p+2:p+3]*size;p+=3
        if len(chunk)!=size:raise ValueError('손상된 IPS 데이터입니다.')
        if offset+size>len(data):data.extend(b'\0'*(offset+size-len(data)))
        data[offset:offset+size]=chunk
    return bytes(data)
if __name__=='__main__':
    if len(sys.argv) not in (2,3):raise SystemExit('python apply_patch.py "Animaniacs (USA).md" [output.md]')
    source=Path(sys.argv[1]);output=Path(sys.argv[2]) if len(sys.argv)==3 else source.with_name('Animaniacs-Korean.md')
    if output.resolve()==source.resolve():raise SystemExit('원본 파일은 덮어쓸 수 없습니다.')
    if output.exists():raise SystemExit('출력 파일이 이미 있습니다. 다른 이름을 지정하세요.')
    patch=Path(__file__).with_name('Animaniacs-Korean.ips')
    if not patch.exists():patch=Path(__file__).resolve().parents[1]/'output/Animaniacs-Korean.ips'
    output.write_bytes(apply(source.read_bytes(),patch.read_bytes()))
    print('완료:',output)
