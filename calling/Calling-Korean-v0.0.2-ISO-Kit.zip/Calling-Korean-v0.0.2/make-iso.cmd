@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0make-iso.ps1"
if errorlevel 1 echo ISO creation failed. Read the message above. The original ISO was not changed.
pause
