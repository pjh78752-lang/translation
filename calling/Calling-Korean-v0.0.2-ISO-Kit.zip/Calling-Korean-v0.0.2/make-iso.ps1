﻿param([string]$IsoPath='', [string]$WitPath='', [string]$OutputIso='')
$ErrorActionPreference='Stop'

function Pick-Input([string]$Title,[string]$Filter) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog=New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title=$Title; $dialog.Filter=$Filter
    try {
        if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'File selection cancelled.' }
        return $dialog.FileName
    } finally { $dialog.Dispose() }
}
function Run-Wit([string[]]$WitArguments) {
    & $script:WitPath @WitArguments
    $status=$LASTEXITCODE
    if ($status -ne 0) { throw "WIT failed (exit $status): $($WitArguments[0]). The original ISO was not modified." }
}
function File-Hash([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }

if (!$WitPath) {
    $command=Get-Command 'wit.exe' -ErrorAction SilentlyContinue
    if ($command) { $WitPath=$command.Source }
    else { $WitPath=Pick-Input 'Select wit.exe from the complete Wiimms ISO Tools folder' 'Wiimms ISO Tool|wit.exe|All files|*.*' }
}
$WitPath=(Get-Item -LiteralPath $WitPath).FullName
Run-Wit @('VERSION')
if (!$IsoPath) { $IsoPath=Pick-Input 'Select the original Calling Japanese SCAJ18 ISO' 'Wii ISO|*.iso|All files|*.*' }
$IsoPath=(Get-Item -LiteralPath $IsoPath).FullName
$stream=[IO.File]::OpenRead($IsoPath)
try {
    [byte[]]$header=New-Object byte[] 32
    if ($stream.Read($header,0,32) -ne 32) { throw 'The source ISO header is incomplete.' }
} finally { $stream.Dispose() }
if ([Text.Encoding]::ASCII.GetString($header,0,6) -ne 'SCAJ18' -or
    [BitConverter]::ToString($header,24,4) -ne '5D-1C-9E-A3') {
    throw 'Select the original Japanese SCAJ18 Wii ISO. Other regions and container formats are not supported by this helper.'
}
if (!$OutputIso) {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog=New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title='Save a NEW Korean ISO; do not choose the original filename'
    $dialog.Filter='Wii ISO|*.iso'; $dialog.FileName='Calling-Korean-v0.0.2.iso'
    $dialog.InitialDirectory=[IO.Path]::GetDirectoryName($IsoPath)
    try {
        if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw 'Output selection cancelled.' }
        $OutputIso=$dialog.FileName
    } finally { $dialog.Dispose() }
}
$OutputIso=[IO.Path]::GetFullPath($OutputIso)
if ([string]::Equals($OutputIso,$IsoPath,[StringComparison]::OrdinalIgnoreCase)) { throw 'The original ISO cannot be overwritten.' }
if (Test-Path -LiteralPath $OutputIso) { throw 'The output already exists. Choose a new filename.' }
if ([IO.Path]::GetExtension($OutputIso) -ine '.iso') { throw 'The output filename must end in .iso.' }
$outputFolder=[IO.Path]::GetDirectoryName($OutputIso)
if (!(Test-Path -LiteralPath $outputFolder -PathType Container)) { throw 'The output directory does not exist.' }
$drive=New-Object IO.DriveInfo ([IO.Path]::GetPathRoot($OutputIso))
if ($drive.DriveFormat -ieq 'FAT32') { throw 'A full Wii ISO requires NTFS or exFAT output storage. Select another drive.' }
$required=(Get-Item -LiteralPath $IsoPath).Length*2+512MB
if ($drive.AvailableFreeSpace -lt $required) { throw 'Allow about 10 GB of free output space for extraction and a new Wii ISO.' }
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw | ConvertFrom-Json
$fileNames=@($manifest.files.PSObject.Properties.Name)
foreach ($name in $fileNames) {
    if (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot "$name.ips") -PathType Leaf)) { throw "Missing patch file: $name.ips" }
}
$work=Join-Path $outputFolder ('calling-iso-work-'+[Guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($work) | Out-Null
$extracted=Join-Path $work 'extracted'
$temporaryIso=Join-Path $work 'rebuilt.iso'
$verification=Join-Path $work 'verify'
Write-Host '[1/5] Extracting the original game DATA partition. The source ISO is read only.'
Run-Wit @('EXTRACT',$IsoPath,$extracted,'--psel','DATA','--pmode','NONE')
$resources=Join-Path $extracted 'files/data'
if (!(Test-Path -LiteralPath $resources -PathType Container)) { throw 'Unexpected WIT extraction layout: files/data was not found.' }
Write-Host '[2/5] Applying Korean patches to newly extracted copies.'
& (Join-Path $PSScriptRoot 'install.ps1') -SourceDirectory $resources -OutputDirectory (Join-Path $work 'riivolution')
$patchedResources=Join-Path $work 'riivolution/calling-ko-v002'
foreach ($name in $fileNames) {
    $expected=$manifest.files.PSObject.Properties[$name].Value
    $patched=Join-Path $patchedResources $name
    if ((File-Hash $patched) -ne $expected.patched_sha256) { throw "Patched asset hash mismatch: $name" }
    [IO.File]::Copy($patched,(Join-Path $resources $name),$true)
}
Write-Host '[3/5] Building a new ISO.'
Run-Wit @('COPY',$extracted,$temporaryIso,'--iso','--no-split')
Write-Host '[4/5] Verifying Wii partition SHA-1 checksums.'
Run-Wit @('VERIFY',$temporaryIso)
Write-Host '[5/5] Reading patched files back out of the new ISO and checking their hashes.'
$verifyArguments=@('EXTRACT',$temporaryIso,$verification,'--psel','DATA','--pmode','NONE')
foreach ($name in $fileNames) { $verifyArguments+=@('--files',('+files/data/'+$name)) }
Run-Wit $verifyArguments
foreach ($name in $fileNames) {
    $expected=$manifest.files.PSObject.Properties[$name].Value
    if ((File-Hash (Join-Path $verification ('files/data/'+$name))) -ne $expected.patched_sha256) {
        throw "Rebuilt ISO asset hash mismatch: $name"
    }
}
[IO.File]::Move($temporaryIso,$OutputIso)
Write-Host "SUCCESS: $OutputIso"
Write-Host 'Open this ISO normally in Dolphin. Riivolution is not needed for this copy.'
Write-Host 'This packages the existing partial v0.0.2 translation; it does not add new translation.'
Write-Host "Original ISO preserved. Temporary extraction retained for inspection: $work"
