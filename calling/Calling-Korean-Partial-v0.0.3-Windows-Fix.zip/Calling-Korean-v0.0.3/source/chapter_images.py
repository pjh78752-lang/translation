"""Translate known chapter/name sprites while retaining sprite metadata/layout."""
from pathlib import Path
import struct
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from archive import read_archive,rebuild

NAMES={0:'스즈타니 신이치',1:'카구라 린',2:'키시베 치요',3:'시라에 마코토'}
CHAPTERS=['빙의','각성','경계','방황','흔적','귀환','연결','통곡','원념','유대']

def decode_rgba(raw):
    width,height=struct.unpack_from('>HH',raw,0x5c)
    length,offset=struct.unpack_from('>II',raw,0x60)
    assert raw[0x58:0x5a]==b'\x20\0'
    assert width%4==height%4==0 and length==width*height*4
    image=Image.new('RGBA',(width,height));data=raw[offset:offset+length];pos=0
    for by in range(0,height,4):
        for bx in range(0,width,4):
            block=data[pos:pos+64];pos+=64
            for y in range(4):
                for x in range(4):
                    k=(y*4+x)*2;alpha,red=block[k:k+2];green,blue=block[32+k:34+k]
                    image.putpixel((bx+x,by+y),(red,green,blue,alpha))
    return image

def encode_rgba(image,raw):
    width,height=image.size;length,offset=struct.unpack_from('>II',raw,0x60)
    assert length==width*height*4;data=bytearray()
    for by in range(0,height,4):
        for bx in range(0,width,4):
            ar=bytearray();gb=bytearray()
            for y in range(4):
                for x in range(4):
                    red,green,blue,alpha=image.getpixel((bx+x,by+y));ar.extend([alpha,red]);gb.extend([green,blue])
            data.extend(ar+gb)
    result=raw[:offset]+data+raw[offset+length:]
    assert len(result)==len(raw)
    return bytes(result)

def make_text(size,text,black=False,vertical=False):
    width,height=size;mask=Image.new('L',size)
    if vertical:text='\n'.join(['의','장'])
    chosen_size=min(88 if black else 36,height-8)
    if vertical:chosen_size=36
    while chosen_size>8:
        font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc',chosen_size,index=1)
        box=ImageDraw.Draw(mask).multiline_textbbox((0,0),text,font=font,spacing=3)
        if box[2]-box[0]<=width-14 and box[3]-box[1]<=height-12:break
        chosen_size-=1
    x=(width-(box[2]-box[0]))//2-box[0];y=(height-(box[3]-box[1]))//2-box[1]
    ImageDraw.Draw(mask).multiline_text((x,y),text,font=font,fill=255,spacing=3,align='center')
    spread=mask.filter(ImageFilter.MaxFilter(7 if black else 3))
    halo=spread.filter(ImageFilter.GaussianBlur(4 if black else 2))
    image=Image.new('RGBA',size,(0,0,0,0));blue=Image.new('RGBA',size,(70,175,245,0));blue.putalpha(halo);image.alpha_composite(blue)
    inner=mask.filter(ImageFilter.GaussianBlur(1));blue=Image.new('RGBA',size,(90,205,255,0));blue.putalpha(inner);image.alpha_composite(blue)
    glyph=Image.new('RGBA',size,(0,0,0,0) if black else (245,250,255,0));glyph.putalpha(mask);image.alpha_composite(glyph)
    return image

def build_chapters(original,output):
    entries=read_archive(original);assert len(entries)==28
    edits={};records=[];previews=[]
    for index,(_,raw,_) in enumerate(entries):
        if index in NAMES:text=NAMES[index];black=False;vertical=False
        elif 4<=index<=23:
            name=CHAPTERS[(index-4)//2];text=name if index%2==0 else name+'의 장';black=True;vertical=False
        elif index==24:text='의 장';black=False;vertical=True
        else:continue
        original_image=decode_rgba(raw);assert encode_rgba(original_image,raw)==raw
        image=make_text(original_image.size,text,black,vertical)
        modified=encode_rgba(image,raw);assert decode_rgba(modified).tobytes()==image.tobytes()
        edits[index]=modified;records.append({'index':index,'korean':text,'dimensions':list(image.size)})
        bg=Image.new('RGBA',image.size,(30,30,30,255));bg.alpha_composite(image);bg.thumbnail((240,180))
        thumb=Image.new('RGB',(260,210),(30,30,30));thumb.paste(bg,(10,20));ImageDraw.Draw(thumb).text((6,4),str(index),fill='white');previews.append(thumb)
    result=rebuild(entries,edits);check=read_archive(result)
    assert all(check[i][1]==edits.get(i,raw) for i,(_,raw,_) in enumerate(entries))
    contact=Image.new('RGB',(1040,210*((len(previews)+3)//4)),(15,15,15))
    for i,preview in enumerate(previews):contact.paste(preview,((i%4)*260,(i//4)*210))
    contact.save(output/'chapter-previews.png')
    return result,records
