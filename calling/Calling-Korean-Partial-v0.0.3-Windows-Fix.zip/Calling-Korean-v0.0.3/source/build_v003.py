"""Build screenshot fix from verified v0.0.2 assets; never overwrite inputs."""
import hashlib,json,struct,zipfile,sys
from pathlib import Path
from archive import read_archive,rebuild
from rfnt import mappings,render_text
ROOT=Path('/workspace/translation/calling')
assets={n:next(Path('/workspace/attachments').rglob(n)).read_bytes() for n in ['font.bin','win_mess_jp_jp.bin','SubTitle.bin']}
z=zipfile.ZipFile(ROOT/'Calling-Korean-Partial-v0.0.2.zip')
base='Calling-Korean-v0.0.2/'
m=json.loads(z.read(base+'manifest.json'))
sha=lambda b:hashlib.sha256(b).hexdigest()
for n,b in assets.items(): assert sha(b)==m['files'][n]['patched_sha256'],n
before=assets['win_mess_jp_jp.bin'];entries=read_archive(before)
lens=list(struct.unpack('>'+str(len(entries[3][1])//2)+'H',entries[3][1]))
def texts(es,ls):
 result=[]
 for bank in range(3):
  off=0
  for i in range(bank*1000,min((bank+1)*1000,len(ls))):
   result.append(es[bank][1][off:off+ls[i]].decode('utf-16-be'));off+=ls[i]
  assert off==len(es[bank][1])
 return result
old=texts(entries,lens)
assert old[2406]=='携帯の持ち主……？\n取りに来るって言ってたけど……'
newtext='휴대전화 주인……?\n찾으러 온다고 했는데……'
new=old.copy();new[2406]=newtext
replacements={}
for bank in range(3):
 replacements[bank]=''.join(new[bank*1000:(bank+1)*1000]).encode('utf-16-be')
newlens=[len(s.encode('utf-16-be')) for s in new]
replacements[3]=struct.pack('>'+str(len(newlens))+'H',*newlens)
after=rebuild(entries,replacements)
assert texts(read_archive(after),newlens)==new
assert sum(a!=b for a,b in zip(old,new))==1
for a,b in zip(old,new): assert [c for c in a if 0xe000<=ord(c)<=0xf8ff]==[c for c in b if 0xe000<=ord(c)<=0xf8ff]
fonts=read_archive(assets['font.bin'])
for _,font,_ in fonts:
 assert all(ord(c) in mappings(font) for c in newtext if 0xac00<=ord(c)<=0xd7a3)
assert all(ord(c) in mappings(fonts[2][1]) for c in newtext if c!='\n')
preview=render_text(fonts[2][1],newtext);preview.save('/workspace/calling-dev/dialogue-2406.png')
# Compose the old original->v002 records with v002->v003 replacement records.
# IPS records apply in order, so later writes override prior writes.
p=z.read(base+'win_mess_jp_jp.bin.ips');assert p[-6:-3]==b'EOF'
patch=bytearray(p[:-6]);pos=0
while pos<len(after):
 if pos<len(before) and before[pos]==after[pos]:pos+=1;continue
 start=pos;pos+=1
 while pos<len(after) and pos-start<65535 and (pos>=len(before) or before[pos]!=after[pos]):pos+=1
 assert start!=0x454f46
 patch+=start.to_bytes(3,'big')+(pos-start).to_bytes(2,'big')+after[start:pos]
patch+=b'EOF'+len(after).to_bytes(3,'big')
def apply(original,ips):
 out=bytearray(original);pos=5;assert ips[:5]==b'PATCH'
 while ips[pos:pos+3]!=b'EOF':
  off=int.from_bytes(ips[pos:pos+3],'big');size=int.from_bytes(ips[pos+3:pos+5],'big');pos+=5
  assert size>0
  if len(out)<off+size:out.extend(b'\0'*(off+size-len(out)))
  out[off:off+size]=ips[pos:pos+size];pos+=size
 assert len(ips)==pos+6
 size=int.from_bytes(ips[pos+3:],'big');return bytes(out[:size]).ljust(size,b'\0')
# Apply composed patch to verified v002, and independently prove composition
# is independent of every source byte that the old patch overwrites.
assert apply(before,patch)==after
for fill in [0,255]:
 surrogate=bytes([fill])*m['files']['win_mess_jp_jp.bin']['original_size']
 assert apply(surrogate,patch)==apply(apply(surrogate,p),patch)
m['version']='0.0.3-screenshot-fix';m['translated_message_entries']=1028
m['files']['win_mess_jp_jp.bin']['patched_sha256']=sha(after)
m['files']['win_mess_jp_jp.bin']['patched_size']=len(after)
m['validation']={'all_2516_slots_checked':True,'unchanged_other_2515_slots':True,'control_tokens_preserved':True,'all_14_fonts_cover_new_hangul':True,'dialogue_font_covers_full_text':True,'v002_input_hashes_verified':True,'composed_ips_verified':True,'dolphin_in_game_tested':False,'windows_powershell_5_1_tested':False,'linux_powershell_installer_tested':False,'original_resource_install_tested':False}
m['screenshot_fix']={'id':2406,'japanese':old[2406],'korean':newtext}
notes='''CALLING 부분 한글화 0.0.3 — 스크린샷 대사 수정\n\n2406번: 휴대전화 주인……? / 찾으러 온다고 했는데……\n기존 0.0.2의 1,027개 번역과 이미지 25개는 유지합니다. 전체 번역은 아닙니다.\n\n새 폴더에 ZIP을 풀어 사용하세요. ISO 제작은 make-iso.cmd에서 보관한 원본 일본판 SCAJ18 ISO를 선택하고 새 파일로 저장하세요. 기존 한국어 ISO에 겹쳐 적용하지 마세요.\n리소스 설치기 install.cmd 역시 원본 일본판 리소스 3개를 요구합니다. 이번에 업로드한 0.0.2 적용본은 원본이 아니므로 설치기 입력으로 사용할 수 없습니다.\n\n대사 2,516개 중 해당 1개만 변경, 제어 문자 보존, 글꼴 14개 한글 지원 및 대사 글꼴 전체 문자 지원, 압축 왕복과 IPS 합성을 검사했습니다. 제공된 파일은 0.0.2 해시와 일치합니다.\n현재 환경에는 원본 리소스와 전체 ISO, PowerShell 및 Dolphin이 없어 원본 대상 설치 실행·ISO 재생성·게임 화면은 이번에 검증하지 못했습니다. previews/dialogue-2406.png는 리소스 렌더링이며 게임 화면이 아닙니다.\n'''
for archive_name in ['Calling-Korean-Partial-v0.0.3.zip','Calling-Korean-v0.0.3-ISO-Kit.zip']:
 src=zipfile.ZipFile(ROOT/('Calling-Korean-v0.0.2-ISO-Kit.zip' if 'ISO-Kit' in archive_name else 'Calling-Korean-Partial-v0.0.2.zip'))
 with zipfile.ZipFile(ROOT/archive_name,'w',zipfile.ZIP_DEFLATED) as out:
  for name in src.namelist():
   rel=name.split('/',1)[1];data=src.read(name)
   if rel=='manifest.json':data=json.dumps(m,ensure_ascii=False,indent=2).encode()
   elif rel=='win_mess_jp_jp.bin.ips':data=bytes(patch)
   elif rel=='source/korean-v002.json':
    t=json.loads(data);t['2406']=newtext;data=json.dumps(t,ensure_ascii=False,indent=2).encode();rel='source/korean-v003.json'
   elif rel.endswith(('.ps1','.cmd','.xml','.txt')) and rel!='FONT-LICENSE.txt':
    s=data.decode('utf-8-sig').replace('0.0.2','0.0.3').replace('v002','v003').replace('1027','1028')
    if rel=='make-iso.ps1':s=s.replace('This packages the existing partial v0.0.3 translation; it does not add new translation.','This packages partial v0.0.3 including screenshot dialogue 2406.')
    data=s.encode('utf-8-sig' if rel.endswith('.ps1') else 'utf-8');rel=rel.replace('0.0.2','0.0.3')
   out.writestr('Calling-Korean-v0.0.3/'+rel,data)
  out.writestr('Calling-Korean-v0.0.3/0.0.3 변경사항.txt',notes.encode('utf-8-sig'))
  out.writestr('Calling-Korean-v0.0.3/previews/dialogue-2406.png',Path('/workspace/calling-dev/dialogue-2406.png').read_bytes())
  out.writestr('Calling-Korean-v0.0.3/source/build_v003.py',Path(__file__).read_bytes())
 with zipfile.ZipFile(ROOT/archive_name) as check:assert check.testzip() is None
 print(archive_name,(ROOT/archive_name).stat().st_size)
print(json.dumps(m['validation'],indent=2));print('New message hash:',sha(after))
