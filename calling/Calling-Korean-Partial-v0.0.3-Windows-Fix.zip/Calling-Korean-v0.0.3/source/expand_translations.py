"""Combine reviewed translation batches and copy exact duplicate messages."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'messages-jp_jp.json').read_text())
translations={}
for name in ['korean-test.json','korean-expansion.json','korean-help-intro.json']:
    batch=json.loads((ROOT/name).read_text());assert not set(batch)&set(translations),(name,'duplicate edited ID')
    translations.update(batch)

rooms={
 '音楽室':'음악실','音楽準備室':'음악 준비실','化学実験室':'화학 실험실','化学準備室':'화학 준비실',
 '多目的室':'다목적실','理科室':'과학실','調理室':'조리실','調理準備室':'조리 준비실',
 '視聴覚室':'시청각실','録音室':'녹음실','LL教室':'어학실','パソコン室':'컴퓨터실',
 '美術室':'미술실','美術準備室':'미술 준비실','被服室':'의상 실습실','進路指導室':'진로 지도실',
 '会議室':'회의실','生徒会室':'학생회실','地学教室':'지구과학실','放送室':'방송실','用務員室':'관리인실',
 '職員玄関':'교직원 현관','図書室':'도서실','図書準備室':'도서 준비실','体育館':'체육관',
 '男子更衣室':'남자 탈의실','女子更衣室':'여자 탈의실','保健室':'보건실','校長室':'교장실','職員室':'교무실',
 '浴室':'욕실','談話室':'휴게실','食堂':'식당','消毒室':'소독실','CT室':'CT실','ドック室':'건강검진실',
 '手術室':'수술실','看護室':'간호실','機材室':'기재실','薬局':'약국','処置室':'처치실','院長室':'병원장실',
 '健康推進室':'건강증진실','外科':'외과','診察室':'진찰실','機能訓練室':'재활훈련실','救急入口':'응급실 입구',
 '洗濯室':'세탁실','ボイラー室':'보일러실','電気室':'전기실','地下資料室':'지하 자료실','霊安室':'영안실',
 '駐車場入口':'주차장 입구','放射線治療室':'방사선 치료실','ナースステーション':'간호사실'
}
for i in range(1467,1551):
    source=rows[i]['text'];label=re.sub(r'と書いてある。?$','',source)
    m=re.fullmatch(r'(\d)-(\d)教室',label);ward=re.fullmatch(r'(\d+)号室',label)
    if m:name=f'{m[1]}학년 {m[2]}반'
    elif ward:name=ward[1]+'호실'
    else:name=rooms[label]
    translations[str(i)]=name+'이라고 적혀 있다.'
for original_id in range(1551,1578):
    translated=translations[str(original_id)]
    translations[str(original_id+30)]=re.sub(r'\s*\(13일 \d\d:\d\d\)$','',translated)
# Compatibility jamo are absent from the original Japanese fonts; use syllables.
translations={k:v.replace('ㅋㅋ','하하') for k,v in translations.items()}
token=lambda s:[c for c in s if 0xe000<=ord(c)<=0xf8ff]
by_original={}
for k,v in translations.items():
    original=rows[int(k)]['text'];assert token(original)==token(v),(k,'control tokens changed')
    key=original.strip()
    if key and key not in by_original:by_original[key]=v
propagated=[]
for row in rows:
    key=row['text'].strip();idx=str(row['id'])
    if idx not in translations and key in by_original:
        value=by_original[key]
        assert token(row['text'])==token(value)
        translations[idx]=value;propagated.append(row['id'])
for k,value in translations.items():
    assert not re.search('[ぁ-ヿ一-鿿]',value),(k,'Japanese text remains in translated entry',value)
required={1306,1570,1600,1601,1614,843,863,818}
assert required<=set(map(int,translations))
output={k:translations[k] for k in sorted(translations,key=int)}
(ROOT/'korean-v002.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
print('Translation entries:',len(output),'including propagated duplicates:',len(propagated))
print('All screenshot examples included:',sorted(required))
