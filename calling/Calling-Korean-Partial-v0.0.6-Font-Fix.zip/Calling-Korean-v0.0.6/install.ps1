﻿param([string]$SourceDirectory = '', [string]$OutputDirectory = '')
$ErrorActionPreference = 'Stop'
if (!$SourceDirectory) { $SourceDirectory = $PSScriptRoot }
if (!$OutputDirectory) { $OutputDirectory = Join-Path $PSScriptRoot 'riivolution' }
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json

function Hash-Bytes([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Apply-IPS([byte[]]$Original, [byte[]]$Patch, [int]$TargetSize) {
    if ([Text.Encoding]::ASCII.GetString($Patch, 0, 5) -ne 'PATCH') { throw 'Invalid IPS header' }
    [byte[]]$result = New-Object byte[] $TargetSize
    [Array]::Copy($Original, $result, [Math]::Min($Original.Length, $TargetSize))
    $pos = 5
    while ($pos + 3 -le $Patch.Length) {
        if ([Text.Encoding]::ASCII.GetString($Patch, $pos, 3) -eq 'EOF') {
            $pos += 3
            if ($Patch.Length -ne $pos + 3) { throw 'Invalid IPS ending' }
            $declared = [int]$Patch[$pos] * 65536 + [int]$Patch[$pos+1] * 256 + [int]$Patch[$pos+2]
            if ($declared -ne $TargetSize) { throw 'IPS target size mismatch' }
            return ,$result
        }
        if ($pos + 5 -gt $Patch.Length) { throw 'Truncated IPS record' }
        $offset = [int]$Patch[$pos] * 65536 + [int]$Patch[$pos+1] * 256 + [int]$Patch[$pos+2]
        $size = [int]$Patch[$pos+3] * 256 + [int]$Patch[$pos+4]
        $pos += 5
        if ($size -eq 0) { throw 'Unexpected RLE record in this patch version' }
        if ($offset + $size -gt $TargetSize -or $pos + $size -gt $Patch.Length) { throw 'IPS record is out of bounds' }
        [Array]::Copy($Patch, $pos, $result, $offset, $size)
        $pos += $size
    }
    throw 'Missing IPS EOF'
}

$fileNames = @($manifest.files.PSObject.Properties.Name)
$prepared = @{}
foreach ($name in $fileNames) {
    $source = Join-Path $SourceDirectory $name
    if (!(Test-Path -LiteralPath $source -PathType Leaf)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.OpenFileDialog
        $dialog.Title = "Select original $name extracted from SCAJ18"
        $dialog.Filter = "$name|$name|All files|*.*"
        $dialog.FileName = $name
        try {
            if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw "File selection cancelled: $name" }
            $source = $dialog.FileName
        } finally { $dialog.Dispose() }
    }
    $metadata = $manifest.files.PSObject.Properties[$name].Value
    [byte[]]$original = [IO.File]::ReadAllBytes($source)
    if ((Hash-Bytes $original) -ne $metadata.original_sha256) { throw "Wrong original file: $name. Select the unchanged Japanese SCAJ18 file." }
    [byte[]]$patch = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot "$name.ips"))
    [byte[]]$result = Apply-IPS $original $patch $metadata.patched_size
    if ((Hash-Bytes $result) -ne $metadata.patched_sha256) { throw "Patched hash mismatch: $name" }
    $prepared[$name] = $result
}

$dataDirectory = Join-Path $OutputDirectory 'calling-ko-v005'
[IO.Directory]::CreateDirectory($dataDirectory) | Out-Null
foreach ($name in $fileNames) {
    $destination = Join-Path $dataDirectory $name
    if (Test-Path -LiteralPath $destination) {
        if ((Hash-Bytes ([IO.File]::ReadAllBytes($destination))) -ne (Hash-Bytes $prepared[$name])) {
            throw "Existing output differs; move it elsewhere first: $destination"
        }
    } else { [IO.File]::WriteAllBytes($destination, $prepared[$name]) }
}
$xmlSource = Join-Path $PSScriptRoot 'Calling-Korean-v0.0.6.xml'
$xmlDestination = Join-Path $OutputDirectory 'Calling-Korean-v0.0.6.xml'
if (Test-Path -LiteralPath $xmlDestination) {
    if ((Hash-Bytes ([IO.File]::ReadAllBytes($xmlDestination))) -ne (Hash-Bytes ([IO.File]::ReadAllBytes($xmlSource)))) {
        throw "Existing XML differs; move it elsewhere first: $xmlDestination"
    }
} else { [IO.File]::Copy($xmlSource, $xmlDestination) }
Write-Host 'SUCCESS: Original ISO and extracted files were not changed.'
Write-Host 'In Dolphin: Start with Riivolution Patches -> Open Riivolution XML.'
Write-Host "Select: $xmlDestination"
Write-Host ('This is a {0}-entry partial Korean translation, not a complete translation.' -f $manifest.translated_message_entries)
