"""Build a limited Calling Korean rendering test; never modifies uploaded originals."""
from pathlib import Path
import hashlib,json,struct,sys
from archive import read_archive,rebuild
from rfnt import add_hangul,mappings,render_text

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'test-patch';OUT.mkdir(exist_ok=True)
def source(name):return next(Path('/workspace/attachments').rglob(name)).read_bytes()
original=source('win_mess_jp_jp.bin');entries=read_archive(original)
lengths=struct.unpack('>'+str(len(entries[3][1])//2)+'H',entries[3][1])
translation={int(k):v for k,v in json.loads((ROOT/'korean-test.json').read_text()).items()}
allchars=set(''.join(translation.values())+'새 게임 불러오기 설정한글 출력 시험 패치');hangul={c for c in allchars if 0xac00<=ord(c)<=0xd7a3}
newlengths=[];replacements={};index=0
for bank in range(3):
    original_data=entries[bank][1];offset=0;newdata=bytearray()
    count=min(1000,len(lengths)-bank*1000)
    for n in range(count):
        size=lengths[index];old=original_data[offset:offset+size];offset+=size
        ja=old.decode('utf-16-be');ko=translation.get(index,ja)
        tokens=lambda s:[c for c in s if 0xe000<=ord(c)<=0xf8ff]
        assert tokens(ja)==tokens(ko),(index,'changed control tokens')
        data=ko.encode('utf-16-be');assert len(data)<65536
        newdata.extend(data);newlengths.append(len(data));index+=1
    assert offset==len(original_data)
    replacements[bank]=bytes(newdata)
replacements[3]=struct.pack('>'+str(len(newlengths))+'H',*newlengths)
message=rebuild(entries,replacements);decoded=read_archive(message)
assert all(decoded[i][1]==replacements[i] for i in range(4))
(OUT/'win_mess_jp_jp.bin').write_bytes(message)
font_original=source('font.bin');fonts=read_archive(font_original);fontdata={};fontchecks=[]
for i,(_,data,_) in enumerate(fonts):
    patched,report=add_hangul(data,hangul,'/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    testchars=''.join(chr(c) for c in mappings(data) if c>=32)[:40]
    assert render_text(data,testchars).tobytes()==render_text(patched,testchars).tobytes()
    newmap=mappings(patched);assert all(ord(c) in newmap for c in hangul)
    preview=render_text(patched,'새 게임 불러오기 설정\n한글 출력 시험 패치')
    preview.resize((preview.width*2,preview.height*2)).save(OUT/f'font-{i:02}-preview.png')
    fontdata[i]=patched;fontchecks.append({'index':i,**report})
font=rebuild(fonts,fontdata)
assert all(read_archive(font)[i][1]==fontdata[i] for i in range(len(fonts)))
(OUT/'font.bin').write_bytes(font)
def ips(before,after):
    patch=bytearray(b'PATCH');pos=0
    while pos<len(after):
        if pos<len(before) and before[pos]==after[pos]:pos+=1;continue
        start=pos;pos+=1
        while pos<len(after) and pos-start<65535 and (pos>=len(before) or before[pos]!=after[pos]):pos+=1
        assert start!=0x454f46
        patch.extend(start.to_bytes(3,'big')+(pos-start).to_bytes(2,'big')+after[start:pos])
    patch.extend(b'EOF'+len(after).to_bytes(3,'big'))
    return patch
manifest={'game_id':'SCAJ18','version':'0.0.1-render-test','total_message_entries':len(lengths),'translated_message_entries':len(translation),'hangul_syllables':len(hangul),'in_game_tested':False,'files':{}}
for name,before,after in [('font.bin',font_original,font),('win_mess_jp_jp.bin',original,message)]:
    (OUT/(name+'.ips')).write_bytes(ips(before,after))
    manifest['files'][name]={'original_sha256':hashlib.sha256(before).hexdigest(),'patched_sha256':hashlib.sha256(after).hexdigest(),'original_size':len(before),'patched_size':len(after)}
manifest['font_validation']=fontchecks
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps({k:v for k,v in manifest.items() if k not in ['files','font_validation']},indent=2))
print('Messages:',len(original),'->',len(message),'Fonts:',len(font_original),'->',len(font))
